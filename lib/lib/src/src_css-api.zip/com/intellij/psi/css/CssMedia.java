package com.intellij.psi.css;

import com.intellij.psi.css.descriptor.CssMediaType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Set;

public interface CssMedia extends CssAtRule {
  CssRuleset[] getRulesets();

  @Nullable
  CssMediumList getMediumList();

  @NotNull
  Set<CssMediaType> getMediaTypes();
}
