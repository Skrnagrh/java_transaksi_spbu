package com.intellij.javaee.customDeployment;

import com.intellij.javaee.deployment.DeploymentSource;

import java.util.Collection;

public interface DeploymentSourcesCollection {

  Collection<DeploymentSource> getItems();

  void addItem(DeploymentSource item);
}
