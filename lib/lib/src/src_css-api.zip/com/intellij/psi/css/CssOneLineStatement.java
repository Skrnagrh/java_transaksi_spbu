package com.intellij.psi.css;

/**
 * User: zolotov
 *
 * Marker class for css elements, that consist of single line
 * and should be terminated with semicolon
 */
public interface CssOneLineStatement extends CssElement {
}
