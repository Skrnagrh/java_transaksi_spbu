package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlReferencesConstraintDefinition extends SqlConstraintDefinition {
}