package com.intellij.psi.css;

import com.intellij.psi.PsiNameIdentifierOwner;
import org.jetbrains.annotations.NotNull;

public interface CssPageRule extends CssAtRule, PsiNameIdentifierOwner, CssNamedElement {
  CssPseudoPage @NotNull [] getPseudoPages();
}
