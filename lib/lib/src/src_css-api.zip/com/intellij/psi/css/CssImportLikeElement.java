package com.intellij.psi.css;

/**
 * Marker for PsiElements that may contain string children with webpack-specific file references, examples: {@link CssImport},
 * {@link org.jetbrains.plugins.scss.psi.SassScssUseAtRule}, {@link org.jetbrains.plugins.scss.psi.SassScssForwardAtRule}
 */
public interface CssImportLikeElement extends CssElement {
}
