package com.intellij.sql.psi;

public interface SqlQualifyClause extends SqlQueryClause {
}
