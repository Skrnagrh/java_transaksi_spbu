package com.intellij.psi.css;

public interface CssMediaExpression extends CssElement {         
  CssMediaExpression[] EMPTY_ARRAY = new CssMediaExpression[0];
}
