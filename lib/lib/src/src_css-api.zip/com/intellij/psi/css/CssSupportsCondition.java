package com.intellij.psi.css;

public interface CssSupportsCondition extends CssElement {
}
