package com.intellij.psi.css.resolve;

import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReferenceBase;

public class CssStyleReferenceStub extends PsiReferenceBase<PsiElement> {
  public CssStyleReferenceStub(PsiElement element, TextRange range) {
    super(element, range);
  }

  @Override
  public PsiElement resolve() {
    return null;
  }
}
