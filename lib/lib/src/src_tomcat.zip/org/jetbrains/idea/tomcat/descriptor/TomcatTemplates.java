package org.jetbrains.idea.tomcat.descriptor;

import com.intellij.javaee.oss.descriptor.JavaeeTemplatesBase;
import com.intellij.javaee.oss.server.JavaeeIntegration;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.tomcat.server.TomcatIntegration;

final class TomcatTemplates extends JavaeeTemplatesBase {
  @NotNull
  @Override
  public JavaeeIntegration getIntegration() {
    return TomcatIntegration.getInstance();
  }
}
