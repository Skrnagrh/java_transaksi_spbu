package com.intellij.sql.psi;

/**
 * Marker interface for external tool instructions and their element types.
 *
 * @author ignatov
 */
public interface IsExternal {
}
