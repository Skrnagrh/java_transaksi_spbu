package com.intellij.psi.css;

import java.util.List;

public interface CssImportList extends CssElement {
  List<CssImport> getImports();
}
