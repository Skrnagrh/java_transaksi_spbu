package com.intellij.persistence;

import com.intellij.database.model.DasColumn;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;

public interface CustomJdbcTypeMapper {
  ExtensionPointName<CustomJdbcTypeMapper> EP_NAME = ExtensionPointName.create("com.intellij.persistence.customJdbcTypeMapper");

  @NotNull
  Collection<String> getMappedJavaTypeFor(DasColumn column, Project project);
}