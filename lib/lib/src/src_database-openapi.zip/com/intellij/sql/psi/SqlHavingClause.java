package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlHavingClause extends SqlQueryClause {
}