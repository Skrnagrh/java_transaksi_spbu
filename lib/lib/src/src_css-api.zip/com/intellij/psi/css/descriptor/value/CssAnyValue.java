package com.intellij.psi.css.descriptor.value;

/**
 * User: zolotov
 * <p/>
 * Describes value that can be ANY css. Uses as a stub for any value.
 */
public interface CssAnyValue extends CssValueDescriptor {
}
