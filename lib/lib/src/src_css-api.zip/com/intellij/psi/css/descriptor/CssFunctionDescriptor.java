package com.intellij.psi.css.descriptor;

import com.intellij.psi.css.CssTermType;
import org.jetbrains.annotations.NotNull;

/**
 * User: zolotov
 * <p/>
 * Represents descriptor of css function
 */
public interface CssFunctionDescriptor extends CssValueOwnerDescriptor, CssNavigableDescriptor {
  @NotNull
  CssTermType getType();
}
