package com.intellij.sql.psi;

/**
 * @author gregsh
 */
public interface SqlCreateCatalogStatement extends SqlCreateStatement {
}
